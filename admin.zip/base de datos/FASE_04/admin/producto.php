<?php
	//Aca estara un mismo formulario para llevar a cabo las tres acciones: CREATE, UPDATE, DELETE
?>