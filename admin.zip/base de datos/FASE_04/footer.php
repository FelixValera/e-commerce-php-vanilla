		</div>

		<!---->
		<div class="footer">
			<div class="footer-top">
				<div class="container">
					<div class="latter">
						<h6>LA MEJOR MANERA DE COMPRAR ONLINE!</h6>
						<div class="clearfix"></div>
					</div>
					<div class="latter-right">
						<p>SEGUINOS</p>
						<ul class="face-in-to">
							<li><a href="http://www.twitter.com/educacionit"><span></span></a></li>
							<li><a href="http://www.facebook.com/educacionIT"><span class="facebook-in"></span></a></li>
							<div class="clearfix"></div>
						</ul>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="footer-bottom-cate cate-bottom">
						<h6>DIRECCIÓN</h6>
						<ul>
							<li>Lavalle 648, 8° Piso</li>
							<li>C.A.B.A.</li>
							<li>Buenos Aires</li>
							<li>Argentina</li>
							<li class="phone">(011) 4328-0457</li>
						</ul>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<!--initiate accordion-->
		<script src="js/custom.js"></script>
	</body>
</html>