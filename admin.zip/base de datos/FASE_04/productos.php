<div class="cat-product">
	<div class="w_content">
		<div class="women">
			<a href="#">
				<h4>Categoria #1 - <span>4449 items</span></h4>
			</a>
			<ul class="w_nav">
				<li>Ordernar por: </li>
				<li><a class="active" href="#">Más recientes</a></li> |
				<li><a href="#">Menor precio</li> |
				<li><a href="#">Mayor precio</a></li> 
				<div class="clearfix"></div>	
			</ul>
			<div class="clearfix"></div>	
		</div>
	</div>
	<!-- grids_of_4 -->
	<div class="grid-product">
		<?php MostrarProductos(); ?>
		<div class="clearfix"></div>
	</div>
</div>